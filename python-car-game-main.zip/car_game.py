import pygame
from pygame.locals import *
import random

pygame.init()
pygame.mixer.init()

# sounds
engine_sound = pygame.mixer.Sound('music.wav')
engine_sound.set_volume(0.3)
crash_sound = pygame.mixer.Sound('lose.mp3')
crash_sound.set_volume(0.5)
win_sound = pygame.mixer.Sound('boyaah.mp3')
win_sound.set_volume(0.5)

# window
width = 530
height = 500
screen_size = (width, height)
screen = pygame.display.set_mode(screen_size)
pygame.display.set_caption('Cars Game')

# colors
gray = (100, 100, 100)
green = (76, 208, 56)
red = (200, 0, 0)
white = (255, 255, 255)
yellow = (255, 232, 0)

# road sizes
road_width = 300
marker_width = 10
marker_height = 50

# lanes
left_lane = 150
center_lane = 250
right_lane = 350
lanes = [left_lane, center_lane, right_lane]

# road and markers
road = (100, 0, road_width, height)
left_edge_marker = (95, 0, marker_width, height)
right_edge_marker = (395, 0, marker_width, height)

# player pos
player_x = 250
player_y = 400

# frame
clock = pygame.time.Clock()
fps = 120

# game state
gameover = False
level_complete = False
score = 0
speed = 2

# UI menu
def main_menu():
    menu = True
    title_font = pygame.font.Font(pygame.font.get_default_font(), 48)
    option_font = pygame.font.Font(pygame.font.get_default_font(), 24)

    while menu:
        for y in range(height):
            blend_color = (green[0] - int(y * 0.1), green[1] - int(y * 0.1), green[2] - int(y * 0.1))
            pygame.draw.line(screen, blend_color, (0, y), (width, y))

        pygame.draw.rect(screen, gray, (width//2 - 150, 80, 300, 80), border_radius=15)
        pygame.draw.rect(screen, white, (width//2 - 150, 80, 300, 80), 3, border_radius=15)
        title_text = title_font.render("\U0001F697 Car Game", True, white)
        screen.blit(title_text, (width // 2 - title_text.get_width() // 2, 95))

        pygame.draw.rect(screen, (50, 50, 50), (width//2 - 140, 200, 280, 100), border_radius=15)
        pygame.draw.rect(screen, white, (width//2 - 140, 200, 280, 100), 2, border_radius=15)

        start_text = option_font.render("Press [S] to Start", True, yellow)
        screen.blit(start_text, (width // 2 - start_text.get_width() // 2, 220))

        quit_text = option_font.render("Press [Q] to Quit", True, red)
        screen.blit(quit_text, (width // 2 - quit_text.get_width() // 2, 250))

        pygame.display.update()

        for event in pygame.event.get():
            if event.type == QUIT:
                pygame.quit()
                quit()
            if event.type == KEYDOWN:
                if event.key == K_s:
                    menu = False
                elif event.key == K_q:
                    pygame.quit()
                    quit()

def show_congratulations_screen():
    screen.fill((30, 30, 30))
    font_big = pygame.font.Font(None, 48)
    font_small = pygame.font.Font(None, 28)

    text1 = font_big.render(" Congratulations!", True, yellow)
    text2 = font_small.render("You reached 20 points!", True, white)
    text3 = font_small.render("Press [ENTER] to play again", True, green)
    text4 = font_small.render("Press [Q] to Quit", True, red)

    screen.blit(text1, (width // 2 - text1.get_width() // 2, 150))
    screen.blit(text2, (width // 2 - text2.get_width() // 2, 210))
    screen.blit(text3, (width // 2 - text3.get_width() // 2, 260))
    screen.blit(text4, (width // 2 - text4.get_width() // 2, 300))

    pygame.display.update()

class Vehicle(pygame.sprite.Sprite):
    def __init__(self, image, x, y):
        pygame.sprite.Sprite.__init__(self)
        image_scale = 45 / image.get_rect().width
        new_width = int(image.get_rect().width * image_scale)
        new_height = int(image.get_rect().height * image_scale)
        self.image = pygame.transform.scale(image, (new_width, new_height))
        self.rect = self.image.get_rect()
        self.rect.center = [x, y]

class PlayerVehicle(Vehicle):
    def __init__(self, x, y):
        image = pygame.image.load('images/car.png')
        super().__init__(image, x, y)

player_group = pygame.sprite.Group()
vehicle_group = pygame.sprite.Group()

player = PlayerVehicle(player_x, player_y)
player_group.add(player)

image_filenames = ['pickup_truck.png', 'semi_trailer.png', 'taxi.png', 'van.png']
vehicle_images = [pygame.image.load('images/' + name) for name in image_filenames]

crash = pygame.image.load('images/crash.png')
crash_rect = crash.get_rect()

main_menu()
engine_sound.play(-1)

running = True
lane_marker_move_y = 0
while running:
    clock.tick(fps)

    if level_complete:
        show_congratulations_screen()
        waiting = True
        while waiting:
            for event in pygame.event.get():
                if event.type == QUIT:
                    waiting = False
                    running = False
                if event.type == KEYDOWN:
                    if event.key == K_RETURN:
                        level_complete = False
                        win_sound.stop()
                        engine_sound.play(-1)
                        score = 0
                        speed = 3
                        vehicle_group.empty()
                        player.rect.center = [player_x, player_y]
                        waiting = False
                    elif event.key == K_q:
                        waiting = False
                        running = False
            pygame.display.update()
        continue


    keys = pygame.key.get_pressed()
    if keys[K_LEFT] and player.rect.center[0] > left_lane:
        player.rect.x -= 5
    if keys[K_RIGHT] and player.rect.center[0] < right_lane:
        player.rect.x += 5

    for event in pygame.event.get():
        if event.type == QUIT:
            running = False

    screen.fill(green)
    pygame.draw.rect(screen, gray, road)
    pygame.draw.rect(screen, yellow, left_edge_marker)
    pygame.draw.rect(screen, yellow, right_edge_marker)

    lane_marker_move_y += speed * 2
    if lane_marker_move_y >= marker_height * 2:
        lane_marker_move_y = 0
    for y in range(marker_height * -2, height, marker_height * 2):
        pygame.draw.rect(screen, white, (left_lane + 45, y + lane_marker_move_y, marker_width, marker_height))
        pygame.draw.rect(screen, white, (center_lane + 45, y + lane_marker_move_y, marker_width, marker_height))

    player_group.draw(screen)

    if len(vehicle_group) < 2:
        add_vehicle = True
        for vehicle in vehicle_group:
            if vehicle.rect.top < vehicle.rect.height * 1.5:
                add_vehicle = False
        if add_vehicle:
            lane = random.choice(lanes)
            image = random.choice(vehicle_images)
            vehicle = Vehicle(image, lane, height / -2)
            vehicle_group.add(vehicle)

    for vehicle in vehicle_group:
        vehicle.rect.y += speed
        if vehicle.rect.top >= height:
            vehicle.kill()
            score += 1
            if score % 5 == 0:
                speed += 1
            if score == 20 and not level_complete:
                engine_sound.stop()
                win_sound.play()
                level_complete = True

    vehicle_group.draw(screen)

    font = pygame.font.Font(pygame.font.get_default_font(), 16)
    text = font.render('Score: ' + str(score), True, white)
  
    text_rect = text.get_rect(topright=(width - 10, 10))
    screen.blit(text, text_rect)

      


    if pygame.sprite.spritecollide(player, vehicle_group, True):
        gameover = True
        engine_sound.stop()
        crash_sound.play()
        crash_rect.center = [player.rect.center[0], player.rect.top]

    if gameover:
        screen.blit(crash, crash_rect)
        pygame.draw.rect(screen, red, (0, 50, width, 100))
        font = pygame.font.Font(pygame.font.get_default_font(), 16)
        text = font.render('Game over. Play again? (Enter Y or N)', True, white)
        text_rect = text.get_rect(center=(width / 2, 100))
        screen.blit(text, text_rect)
        pygame.display.update()

        while gameover:
            clock.tick(fps)
            for event in pygame.event.get():
                if event.type == QUIT:
                    gameover = False
                    running = False
                if event.type == KEYDOWN:
                    if event.key == K_y:
                        crash_sound.stop()
                        engine_sound.play(-1)
                        gameover = False
                        speed = 2
                        score = 0
                        vehicle_group.empty()
                        player.rect.center = [player_x, player_y]
                    elif event.key == K_n:
                        gameover = False
                        running = False

    pygame.display.update()

engine_sound.stop()
pygame.quit()
